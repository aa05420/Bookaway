import 'package:flutter/material.dart';

const primary = Color.fromARGB(255, 31, 165, 165);
const secondary = Color.fromARGB(255, 255, 255, 255);
const mainColor = Color.fromARGB(255, 108, 211, 209);
const appBgColor = Color.fromARGB(255, 192, 237, 234);
const bottomBarColor = Color.fromARGB(255, 55, 101, 101);
const shadowColor = Color.fromARGB(255, 107, 187, 183);
